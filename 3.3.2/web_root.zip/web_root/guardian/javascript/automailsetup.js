var emailPref = '~[displaypref:email~(curschoolid)]';
if (emailPref === '1') {
    window.location.href = '/guardian/home_not_available.html';
}